// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Muro.h"
#include "MuroLadrillo.generated.h"

/**
 * 
 */
UCLASS()
class PLATAFORMASSPAWN_API AMuroLadrillo : public AMuro
{
	GENERATED_BODY()
	
};
